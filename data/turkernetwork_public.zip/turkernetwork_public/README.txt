This dataset contains information on the communication network structure within a group of 
10,354 Amazon Mechanical Turk workers. Each worker is identified with an integer between
1 and 10,354. In turker_network.csv, each row corresponds to two workers who reported to communicate
with each other.

If you want to cite this dataset, please cite the following paper:

"The Communication Network within the Crowd. M. Yin, M. L. Gray, S. Suri, & J. W. Vaughan. 
Proceedings of the 25th International World Wide Web Conference."
