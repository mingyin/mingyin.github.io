This dataset contains 3 sets of data on crowd work quality under monetary interventions in 3 different types of tasks:
- puzzle.csv: crowd work quality in word puzzle games
- classify.csv: crowd work quality in butterfly classification tasks
- typo.csv: crowd work quality in typo-finding tasks

Please see the paper for more detailed descriptions for the tasks.

Each row of a .csv file represents a task that a worker completes. 
- workerId: a randomly generated string identifier of the worker
- game: the order of the task in the task sequence. For example, '2' means this row represents the second task that the worker completes in the sequence.
- haveBonus: a binary value representing whether a bonus is provided in a task (0: no; 1: yes)
- highQuality: a binary value representing whether the work quality in the task is high (0: low quality; 1: high quality)

If you want to cite this dataset, please cite the following paper:

"Predicting Crowd Work Quality under Monetary Interventions. M. Yin and Y. Chen. Proceedings of the 4th AAAI Conference on Human Computation and Crowdsourcing."